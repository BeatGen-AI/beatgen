import { describe, it, expect, beforeEach, vi } from 'vitest';
import { MidiManager } from '../../midi/MidiManagerNew';
import { Note } from '../../../../types/note';
import { CombinedTrackEntity } from '../../../../platform/types/entities/project';
import { TrackInstance } from '../../../../platform/types/dto/project';

describe('Instance Playback Position Verification', () => {
    let midiManager: MidiManager;
    
    // Test data
    const trackId = 'track-1';
    const testNotes: Note[] = [
        {
            id: 'note-1',
            trackId,
            column: 0, // Start of the pattern
            pitch: 60,
            length: 480, // 1 beat
            velocity: 100,
            row: 0
        },
        {
            id: 'note-2',
            trackId,
            column: 480, // 1 beat in
            pitch: 64,
            length: 480,
            velocity: 100,
            row: 0
        },
        {
            id: 'note-3',
            trackId,
            column: 960, // 2 beats in
            pitch: 67,
            length: 480,
            velocity: 100,
            row: 0
        }
    ];
    
    const testTrack: CombinedTrackEntity = {
        id: trackId,
        name: 'Test Track',
        volume: 1,
        pan: 0,
        mute: false,
        duration_ticks: 1920, // 4 beats
        track_number: 0,
        track_type: 'MIDI',
        instances: [
            {
                id: 'instance-1',
                x_position: 0,
                y_position: 0,
                trim_start_ticks: 0,
                trim_end_ticks: 1920
            },
            {
                id: 'instance-2',
                x_position: 1920, // 4 beats later
                y_position: 0,
                trim_start_ticks: 0,
                trim_end_ticks: 1920
            },
            {
                id: 'instance-3',
                x_position: 3840, // 8 beats later
                y_position: 0,
                trim_start_ticks: 480, // Skip first beat
                trim_end_ticks: 1440 // End after 3 beats from start
            }
        ],
        track: {
            id: trackId,
            name: 'Test Track',
            instrument_id: 'instrument-1',
            midi_notes_json: {},
            instrument_file: {
                id: 'instrument-1',
                file_name: 'test.sf2',
                display_name: 'Test Instrument',
                storage_key: 'test-key',
                file_format: 'sf2',
                file_size: 1000,
                category: 'test',
                is_public: true,
                description: null
            }
        }
    };

    beforeEach(() => {
        midiManager = new MidiManager();
        
        // Add the track and notes
        midiManager.createTrack(trackId);
        testNotes.forEach(note => {
            midiManager.addNoteToTrack(trackId, note);
        });
    });

    describe('getInstanceNotesForPlayback', () => {
        it('should return notes at correct positions for instance 1 (x_position = 0)', () => {
            const instance = testTrack.instances![0];
            const playableNotes = midiManager.getInstanceNotesForPlayback(
                trackId,
                instance.id,
                instance.x_position,
                instance.trim_start_ticks,
                instance.trim_end_ticks
            );
            
            expect(playableNotes).toHaveLength(3);
            
            // Notes should be at their original positions since x_position = 0
            expect(playableNotes[0].column).toBe(0);
            expect(playableNotes[1].column).toBe(480);
            expect(playableNotes[2].column).toBe(960);
        });
        
        it('should return notes at correct positions for instance 2 (x_position = 1920)', () => {
            const instance = testTrack.instances![1];
            const playableNotes = midiManager.getInstanceNotesForPlayback(
                trackId,
                instance.id,
                instance.x_position,
                instance.trim_start_ticks,
                instance.trim_end_ticks
            );
            
            expect(playableNotes).toHaveLength(3);
            
            // Notes should be shifted by x_position (1920 ticks)
            expect(playableNotes[0].column).toBe(1920); // 0 + 1920
            expect(playableNotes[1].column).toBe(2400); // 480 + 1920
            expect(playableNotes[2].column).toBe(2880); // 960 + 1920
        });
        
        it('should return notes at correct positions for instance 3 with trim (x_position = 3840)', () => {
            const instance = testTrack.instances![2];
            const playableNotes = midiManager.getInstanceNotesForPlayback(
                trackId,
                instance.id,
                instance.x_position,
                instance.trim_start_ticks,
                instance.trim_end_ticks
            );
            
            // Only notes 2 and 3 should be included due to trim_start_ticks = 480
            expect(playableNotes).toHaveLength(2);
            
            // Notes should be shifted by x_position (3840 ticks)
            // Note 2 starts at 480, which equals trim_start, so it's included
            expect(playableNotes[0].column).toBe(4320); // 480 + 3840
            expect(playableNotes[0].pitch).toBe(64); // Verify it's note 2
            
            // Note 3 starts at 960, within trim range
            expect(playableNotes[1].column).toBe(4800); // 960 + 3840
            expect(playableNotes[1].pitch).toBe(67); // Verify it's note 3
        });
        
        it('should handle overlapping instances correctly', () => {
            // Create instances that would overlap in time
            const overlappingTrack: CombinedTrackEntity = {
                ...testTrack,
                instances: [
                    {
                        id: 'instance-a',
                        x_position: 0,
                        y_position: 0,
                        trim_start_ticks: 0,
                        trim_end_ticks: 1920
                    },
                    {
                        id: 'instance-b',
                        x_position: 960, // Overlaps with instance-a
                        y_position: 1,
                        trim_start_ticks: 0,
                        trim_end_ticks: 1920
                    }
                ]
            };
            
            // Get notes for both instances
            const notesA = midiManager.getInstanceNotesForPlayback(
                trackId,
                'instance-a',
                0,
                0,
                1920
            );
            
            const notesB = midiManager.getInstanceNotesForPlayback(
                trackId,
                'instance-b',
                960,
                0,
                1920
            );
            
            // Verify instance A plays at original positions
            expect(notesA[0].column).toBe(0);
            expect(notesA[1].column).toBe(480);
            expect(notesA[2].column).toBe(960);
            
            // Verify instance B plays shifted by 960 ticks
            expect(notesB[0].column).toBe(960); // 0 + 960
            expect(notesB[1].column).toBe(1440); // 480 + 960
            expect(notesB[2].column).toBe(1920); // 960 + 960
        });
        
        it('should return empty array for instances with trim range outside note range', () => {
            const instance: TrackInstance = {
                id: 'instance-empty',
                x_position: 0,
                y_position: 0,
                trim_start_ticks: 2000, // Beyond all notes
                trim_end_ticks: 3000
            };
            
            const playableNotes = midiManager.getInstanceNotesForPlayback(
                trackId,
                instance.id,
                instance.x_position,
                instance.trim_start_ticks,
                instance.trim_end_ticks
            );
            
            expect(playableNotes).toHaveLength(0);
        });
    });
    
    describe('Timing calculations', () => {
        it('should calculate correct timing for notes at different BPMs', () => {
            const bpm = 120;
            const ppq = 480;
            
            // Test timing calculations for each instance
            const instances = testTrack.instances!;
            
            instances.forEach((instance, idx) => {
                const playableNotes = midiManager.getInstanceNotesForPlayback(
                    trackId,
                    instance.id,
                    instance.x_position,
                    instance.trim_start_ticks,
                    instance.trim_end_ticks
                );
                
                playableNotes.forEach(note => {
                    // Calculate expected time in seconds
                    const beats = note.column / ppq;
                    const expectedTimeInSeconds = beats * (60 / bpm);
                    
                    // Verify the calculation
                    const actualBeats = note.column / ppq;
                    const actualTimeInSeconds = actualBeats * (60 / bpm);
                    
                    expect(actualTimeInSeconds).toBe(expectedTimeInSeconds);
                });
            });
        });
    });
});